/* Recharge & Reconnect - shared client helpers */
(function () {
  let AC = null;
  const soundOn = () => true;
  function beep(f, d, type, v, when) {
    if (!soundOn()) return;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      if (AC.state === 'suspended') AC.resume();
      const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime + (when || 0);
      o.type = type || 'square'; o.frequency.value = f;
      g.gain.setValueAtTime(v || 0.05, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d);
    } catch (e) {}
  }
  const sfx = {
    click() { beep(440, 0.05); },
    coin() { beep(988, 0.08); beep(1319, 0.22, 'square', 0.05, 0.08); },
    level() { [523, 659, 784, 1047, 1319].forEach((f, i) => beep(f, 0.14, 'square', 0.05, i * 0.1)); },
    err() { beep(160, 0.25, 'sawtooth'); },
    loot() { for (let i = 0; i < 8; i++) beep(300 + i * 90, 0.07, 'square', 0.04, i * 0.06); },
    win() { [784, 988, 1175, 1568].forEach((f, i) => beep(f, 0.2, 'square', 0.05, i * 0.12)); },
  };

  let bgmStarted = false;
  function startBGM() {
    if (!soundOn()) return;
    if (bgmStarted) {
      if (AC && AC.state === 'suspended') AC.resume();
      return;
    }
    bgmStarted = true;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      if (AC.state === 'suspended') AC.resume();
      const notes = [261.63, 311.13, 392.00, 523.25, 261.63, 311.13, 392.00, 523.25, 293.66, 349.23, 440.00, 587.33, 261.63, 311.13, 392.00, 523.25];
      let t = AC.currentTime + 0.1;
      let i = 0;
      function schedule() {
        if (AC.state === 'suspended') AC.resume();
        if (t < AC.currentTime) t = AC.currentTime + 0.1;
        while (t < AC.currentTime + 1.0) {
          const o = AC.createOscillator(), g = AC.createGain();
          o.type = 'triangle';
          o.frequency.value = notes[i % notes.length];
          g.gain.setValueAtTime(0.04, t);
          g.gain.setTargetAtTime(0, t, 0.03);
          o.connect(g); g.connect(AC.destination);
          o.start(t); o.stop(t + 0.18);
          t += 0.2;
          i++;
        }
        setTimeout(schedule, 200);
      }
      schedule();
    } catch(e){
      console.error('BGM Error:', e);
    }
  }


  function toast(msg, kind) {
    let box = document.getElementById('toasts');
    if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast ' + (kind || '');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.classList.add('out'), 2600);
    setTimeout(() => t.remove(), 3100);
  }

  function confetti(n) {
    const cols = ['#00e5ff', '#b14cff', '#ffe600', '#39ff14', '#ff3860'];
    for (let i = 0; i < (n || 46); i++) {
      const p = document.createElement('i');
      p.className = 'confetti';
      p.style.cssText = `left:${Math.random() * 100}vw;background:${cols[i % 5]};animation-delay:${Math.random() * .6}s;animation-duration:${1.6 + Math.random() * 1.4}s`;
      document.body.appendChild(p);
      setTimeout(() => p.remove(), 3500);
    }
  }

  function fx(f) {
    if (!f) return;
    let d = 0;
    const later = (fn) => setTimeout(fn, d += 450);
    if (f.xp) { toast('+' + f.xp + ' XP' + (f.tp ? '  +' + f.tp + ' TP' : ''), 'xp'); sfx.coin(); }
    else if (f.tp) { toast('+' + f.tp + ' Treasure Points', 'xp'); sfx.coin(); }
    (f.badges || []).forEach(b => later(() => { toast('BADGE: ' + b, 'badge'); sfx.win(); }));
    if (f.levelup) later(() => levelUp(f.levelup));
  }

  function levelUp(l) {
    const o = document.createElement('div');
    o.className = 'overlay lvlup';
    o.innerHTML = `<div class="card pop"><p class="big">LEVEL UP!</p><p class="lv">LV ${l}</p><button class="btn">LANJUT</button></div>`;
    o.querySelector('button').onclick = () => o.remove();
    document.body.appendChild(o);
    sfx.level(); confetti();
  }

  function resolveUrl(u) {
    if (!u) return u;
    const root = (window.ROOT_PATH || '').replace(/\/$/, '');
    if (!root) return u;
    if (u === '/') return root + '/';
    if (u.startsWith('/') && !u.startsWith(root + '/') && u !== root) {
      return root + u;
    }
    return u;
  }

  async function post(url, body) {
    url = resolveUrl(url);
    const opt = { method: 'POST', credentials: 'same-origin' };
    if (body instanceof FormData) opt.body = body;
    else { opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(body || {}); }
    let r, j;
    try { r = await fetch(url, opt); j = await r.json(); }
    catch (e) { toast('Koneksi bermasalah. Coba lagi.', 'err'); sfx.err(); return { ok: false, msg: 'network' }; }
    if (r.status === 401 && j.redirect) { location.href = resolveUrl(j.redirect); return j; }
    if (j.fx) fx(j.fx);
    if (!j.ok && j.msg) { toast(j.msg, 'err'); sfx.err(); }
    return j;
  }

  function countdown(el, iso, done) {
    const t = new Date(iso.length === 16 ? iso + ':00+07:00' : iso + '+07:00').getTime();
    const q = k => el.querySelector('[data-' + k + ']');
    function tick() {
      let s = Math.floor((t - Date.now()) / 1000);
      if (s <= 0) { el.innerHTML = '<p class="gameon">GAME ON!</p>'; if (done) done(); return; }
      const d = Math.floor(s / 86400); s %= 86400;
      const h = Math.floor(s / 3600); s %= 3600;
      const m = Math.floor(s / 60); s %= 60;
      const z = n => String(n).padStart(2, '0');
      q('d').textContent = z(d); q('h').textContent = z(h); q('m').textContent = z(m); q('s').textContent = z(s);
      setTimeout(tick, 1000);
    }
    tick();
  }

  document.addEventListener('touchstart', startBGM, {once: true});
  document.addEventListener('click', e => {
    startBGM();
    if (e.target.closest('.btn, .node, .tab, .avopt, .opt')) sfx.click();
    const lk = e.target.closest('[data-locked]');
    if (lk) { e.preventDefault(); toast('Selesaikan misi sebelumnya dulu.', 'err'); sfx.err(); }
  });
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('form[data-confirm]').forEach(f => f.addEventListener('submit', e => {
      if (!confirm(f.dataset.confirm)) e.preventDefault();
    }));
  });

  window.RR = { post, toast, fx, sfx, confetti, countdown, levelUp, url: resolveUrl };
})();
