"""Recharge & Reconnect - Retro Arcade outing app (Flask + Waitress + SQLite)."""
import os, io, csv, math, random, secrets, shutil, sqlite3, threading, time, zipfile, tempfile
from datetime import datetime, timedelta, timezone, time as dtime
from functools import wraps
from flask import (Flask, g, request, session, redirect, render_template, jsonify, abort,
                   send_file, send_from_directory, flash)
from werkzeug.security import generate_password_hash, check_password_hash
from PIL import Image, ImageOps
try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except Exception:
    pass
import db as D

BASE = os.path.dirname(os.path.abspath(__file__))
UPLOADS = os.environ.get('RR_UPLOADS') or os.path.join(BASE, 'uploads')
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(os.path.join(BASE, 'data'), exist_ok=True)
WIB = timezone(timedelta(hours=7))

app = Flask(__name__)


class ReverseProxyPrefixMiddleware:
    """WSGI middleware for reverse proxy support under a subpath (e.g. /outing)."""
    def __init__(self, wsgi_app, prefix='/outing'):
        self.app = wsgi_app
        self.prefix = (os.environ.get('APP_PREFIX', prefix) or '').rstrip('/')

    def __call__(self, environ, start_response):
        proto = environ.get('HTTP_X_FORWARDED_PROTO')
        if proto:
            environ['wsgi.url_scheme'] = proto

        host = environ.get('HTTP_X_FORWARDED_HOST')
        if host:
            environ['HTTP_HOST'] = host

        fwd_prefix = environ.get('HTTP_X_FORWARDED_PREFIX', '').strip().rstrip('/')
        path = environ.get('PATH_INFO', '')
        prefix = fwd_prefix or self.prefix

        if prefix:
            if path == prefix:
                environ['SCRIPT_NAME'] = prefix
                environ['PATH_INFO'] = '/'
            elif path.startswith(prefix + '/'):
                environ['SCRIPT_NAME'] = prefix
                environ['PATH_INFO'] = path[len(prefix):] or '/'
            elif fwd_prefix:
                environ['SCRIPT_NAME'] = fwd_prefix
            elif environ.get('HTTP_X_FORWARDED_FOR') or environ.get('HTTP_X_REAL_IP'):
                environ['SCRIPT_NAME'] = prefix

        return self.app(environ, start_response)


app.wsgi_app = ReverseProxyPrefixMiddleware(app.wsgi_app, prefix=os.environ.get('APP_PREFIX', '/outing'))


def _secret():
    if os.environ.get('SECRET_KEY'):
        return os.environ['SECRET_KEY']
    p = os.path.join(BASE, 'data', 'secret.key')
    if not os.path.exists(p):
        with open(p, 'w') as f:
            f.write(secrets.token_hex(32))
    return open(p).read().strip()


app.config.update(
    SECRET_KEY=_secret(), MAX_CONTENT_LENGTH=25 * 1024 * 1024,
    PERMANENT_SESSION_LIFETIME=timedelta(days=365),
    SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE', '0') == '1',
    SESSION_COOKIE_PATH=os.environ.get('COOKIE_PATH', '/'),
    TEMPLATES_AUTO_RELOAD=True)
app.teardown_appcontext(D.close)
D.init_db()

AVATARS = [('knight', 'Ksatria'), ('ninja', 'Ninja'), ('robot', 'Robot'),
           ('astro', 'Astronot'), ('wizard', 'Penyihir'), ('cat', 'Kucing')]
AV_KEYS = [a[0] for a in AVATARS]
CAT_SPRITE = {'vehicle': 'bus', 'meal': 'food', 'game': 'game', 'activity': 'flag', 'rest': 'star'}
CATS = ['vehicle', 'activity', 'meal', 'game', 'rest']


# ------------------------------------------------------------------ helpers
def now():
    return datetime.now(WIB)


def ts():
    return now().strftime('%Y-%m-%d %H:%M:%S')


def setting(key, default=''):
    v = D.val('SELECT value FROM settings WHERE key=?', (key,))
    return v if v is not None else default


def set_setting(key, value):
    D.ex('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, value))


def event_start():
    try:
        return datetime.fromisoformat(setting('event_start')).replace(tzinfo=WIB)
    except Exception:
        return datetime(2026, 10, 16, 6, 0, tzinfo=WIB)


def level_of(xp):
    return int((1 + math.sqrt(1 + xp / 12.5)) / 2)


def lvl_info(xp):
    L = level_of(xp)
    return L, xp - 50 * L * (L - 1), 100 * L


def u(path=''):
    prefix = (request.script_root or '').rstrip('/')
    if not path or path == '/':
        return (prefix + '/') if prefix else '/'
    if path.startswith('/'):
        return f"{prefix}{path}"
    return f"{prefix}/{path}"


def redr(target):
    if target.startswith('/'):
        return redirect(u(target))
    return redirect(target)


def err(msg, code=400):
    return jsonify(ok=False, msg=msg), code


def fxs():
    if 'fx' not in g:
        g.fx = {'xp': 0, 'tp': 0, 'levelup': None, 'badges': []}
        g.lv0 = level_of(g.me['xp']) if g.me else 1
    return g.fx


def recompute(pid):
    D.ex('''UPDATE participants SET
        xp=(SELECT COALESCE(SUM(xp),0) FROM xp_log WHERE participant_id=?),
        treasure_points=(SELECT COALESCE(SUM(tp),0) FROM xp_log WHERE participant_id=?) WHERE id=?''', (pid, pid, pid))


def award(pid, source, source_id, xp, tp=0):
    """Idempotent XP award. Returns True only the first time per (participant, source, source_id)."""
    mine = bool(g.me) and g.me['id'] == pid
    if mine:
        fxs()
    try:
        D.ex('INSERT INTO xp_log(participant_id,source,source_id,xp,tp,created_at) VALUES(?,?,?,?,?,?)',
             (pid, source, str(source_id), xp, tp, ts()))
    except sqlite3.IntegrityError:
        return False
    recompute(pid)
    if mine:
        f = g.fx
        f['xp'] += xp
        f['tp'] += tp
        new = D.val('SELECT xp FROM participants WHERE id=?', (pid,))
        if level_of(new) > g.lv0:
            f['levelup'] = level_of(new)
    return True


def grant_badge(pid, code):
    b = D.one('SELECT id,name FROM badges WHERE code=?', (code,))
    if not b:
        return False
    cur = D.ex('INSERT OR IGNORE INTO participant_badges(participant_id,badge_id,earned_at) VALUES(?,?,?)', (pid, b['id'], ts()))
    if cur.rowcount and g.me and g.me['id'] == pid:
        fxs()['badges'].append(b['name'])
        return True
    return bool(cur.rowcount)


def today_day():
    return (now().date() - event_start().date()).days + 1


def has_approved_photo(pid):
    return bool(D.val("SELECT 1 FROM photo_uploads WHERE participant_id=? AND status='approved' LIMIT 1", (pid,)))


def claim_code():
    while True:
        c = 'RR-' + ''.join(secrets.choice(D.ALPHA) for _ in range(4))
        if not D.one('SELECT 1 FROM reward_assignments WHERE claim_code=?', (c,)):
            return c


# ------------------------------------------------------------------ auth
@app.before_request
def load_user():
    g.me = None
    if request.endpoint == 'static':
        return
    pid = session.get('pid')
    if pid:
        p = D.one('SELECT * FROM participants WHERE id=?', (pid,))
        if p and p['session_epoch'] == session.get('ep'):
            g.me = p
        else:
            session.pop('pid', None)


def participant_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.me:
            if request.method != 'GET' or request.path.startswith('/api'):
                return jsonify(ok=False, msg='Sesi habis, masukkan kode lagi.', redirect=u('/')), 401
            return redr('/')
        return f(*a, **k)
    return w


def admin_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get('admin'):
            return redr('/admin/login')
        return f(*a, **k)
    return w


@app.context_processor
def inject():
    d = {'me': g.get('me'), 'S': setting, 'AVATARS': AVATARS, 'CAT_SPRITE': CAT_SPRITE, 'u': u}
    if g.get('me'):
        L, into, need = lvl_info(g.me['xp'])
        d['lv'] = dict(L=L, into=into, need=need, pct=int(into * 100 / need))
    return d


@app.after_request
def no_cache(r):
    if request.path.startswith('/api') or request.path.startswith('/admin'):
        r.headers['Cache-Control'] = 'no-store'
    return r


@app.get('/manifest.json')
def manifest():
    return jsonify(name='Recharge & Reconnect', short_name='R&R', start_url=u('/'), display='standalone',
                   background_color='#0b0b2b', theme_color='#0b0b2b')


# ------------------------------------------------------------------ participant pages
@app.get('/')
def landing():
    if g.me:
        return redr('/map')
    return render_template('landing.html')


@app.post('/api/login')
def api_login():
    d = request.get_json(silent=True) or request.form
    code = (d.get('code') or '').strip().upper().replace(' ', '')
    p = D.one('SELECT * FROM participants WHERE code=?', (code,))
    if not p:
        return err('Kode tidak ditemukan. Cek lagi kode dari panitia.', 404)
    session.permanent = True
    session['pid'] = p['id']
    session['ep'] = p['session_epoch']
    g.me = p
    first = not p['first_login']
    av = d.get('avatar')
    if av in AV_KEYS and (first or not p['avatar']):
        D.ex('UPDATE participants SET avatar=? WHERE id=?', (av, p['id']))
    if first:
        D.ex('UPDATE participants SET first_login=? WHERE id=?', (ts(), p['id']))
        award(p['id'], 'welcome', '1', 50)
        grant_badge(p['id'], 'player_one')
        if now() < event_start():
            grant_badge(p['id'], 'early_bird')
    return jsonify(ok=True, redirect=u('/map'), code=code, fx=fxs() if first else None)


@app.get('/logout')
def logout():
    session.pop('pid', None)
    return redr('/')


def missions(pid):
    sc = lambda s, a=(): D.val(s, a) or 0
    ag_t = sc('SELECT COUNT(*) FROM agenda')
    ag_o = sc('SELECT COUNT(*) FROM participant_agenda WHERE participant_id=?', (pid,))
    in_t = sc('SELECT COUNT(*) FROM checklist_items')
    in_c = sc('SELECT COUNT(*) FROM participant_checklist WHERE participant_id=?', (pid,))
    rules = sc("SELECT COUNT(*) FROM xp_log WHERE participant_id=? AND source='rules'", (pid,))
    lunch = sc('SELECT COUNT(*) FROM lunch_choices WHERE participant_id=?', (pid,))
    ph = sc("SELECT COUNT(*) FROM photo_uploads WHERE participant_id=? AND status='approved'", (pid,))
    rw = sc('SELECT COUNT(*) FROM reward_assignments WHERE participant_id=? AND opened_at IS NOT NULL', (pid,))
    M = [
        dict(key='rundown', title='Event Rundown', url=u('/rundown'), sprite='bus', done=ag_t > 0 and ag_o >= ag_t, detail=f'{ag_o}/{ag_t} level'),
        dict(key='rules', title="Do's & Don'ts", url=u('/rules'), sprite='check', done=rules > 0, detail='Kartu item'),
        dict(key='inventory', title='Inventory Bag', url=u('/inventory'), sprite='bag', done=in_t > 0 and in_c >= in_t, detail=f'{in_c}/{in_t} barang'),
        dict(key='lunch', title='Lunch Day 2', url=u('/lunch'), sprite='food', done=lunch > 0, detail='Pilih menu'),
        dict(key='treasure', title='Treasure Hunt', url=u('/treasure'), sprite='cam', done=ph > 0, detail='Foto Garut'),
        dict(key='reward', title='Boss: Loot Box', url=u('/reward'), sprite='chest', done=rw > 0, detail='Hadiah'),
    ]
    strict = setting('strict_map') == '1'
    prev = True
    for m in M:
        m['open'] = M[4]['done'] if m['key'] == 'reward' else ((not strict) or prev)
        prev = m['done']
    cur = next((i for i, m in enumerate(M) if m['open'] and not m['done']), None)
    return M, cur


@app.get('/map')
@participant_required
def map_page():
    M, cur = missions(g.me['id'])
    done = sum(m['done'] for m in M)
    return render_template('map.html', M=M, cur=cur, done=done, total=len(M), pct=int(done * 100 / len(M)))


def _agenda_rows():
    base = event_start().date()
    rows = []
    opened = {r[0] for r in D.q('SELECT agenda_id FROM participant_agenda WHERE participant_id=?', (g.me['id'],))}
    for r in D.q('SELECT * FROM agenda ORDER BY day,start_time'):
        d = dict(r)
        try:
            day = base + timedelta(days=r['day'] - 1)
            st = datetime.combine(day, dtime.fromisoformat(r['start_time'])).replace(tzinfo=WIB)
            en = datetime.combine(day, dtime.fromisoformat(r['end_time'])).replace(tzinfo=WIB) if r['end_time'] else st + timedelta(hours=1)
            n = now()
            d['state'] = 'done' if n > en else ('now' if n >= st else 'next')
        except Exception:
            d['state'] = 'next'
        d['opened'] = r['id'] in opened
        d['sprite'] = CAT_SPRITE.get(r['category'], 'flag')
        rows.append(d)
    return rows


@app.get('/rundown')
@participant_required
def rundown():
    rows = _agenda_rows()
    days = sorted({r['day'] for r in rows}) or [1]
    td = today_day()
    active = td if td in days else days[0]
    return render_template('rundown.html', rows=rows, days=days, active=active, base=event_start().date())


@app.post('/api/agenda/<int:aid>/open')
@participant_required
def api_agenda_open(aid):
    a = D.one('SELECT * FROM agenda WHERE id=?', (aid,))
    if not a:
        return err('Level tidak ditemukan', 404)
    D.ex('INSERT OR IGNORE INTO participant_agenda(participant_id,agenda_id,opened_at) VALUES(?,?,?)', (g.me['id'], aid, ts()))
    award(g.me['id'], 'agenda', aid, 10)
    return jsonify(ok=True, location=a['location'] or '', note=a['note'] or '', fx=fxs())


@app.get('/rules')
@participant_required
def rules():
    cards = D.q('SELECT * FROM rules_cards ORDER BY type DESC, rarity DESC, id')
    done = bool(D.val("SELECT 1 FROM xp_log WHERE participant_id=? AND source='rules'", (g.me['id'],)))
    return render_template('rules.html', cards=cards, done=done)


@app.post('/api/rules/complete')
@participant_required
def api_rules_complete():
    award(g.me['id'], 'rules', '1', 20)
    grant_badge(g.me['id'], 'rule_keeper')
    return jsonify(ok=True, fx=fxs())


@app.get('/inventory')
@participant_required
def inventory():
    items = D.q('''SELECT i.*, (SELECT 1 FROM participant_checklist c WHERE c.item_id=i.id AND c.participant_id=?) checked
                   FROM checklist_items i ORDER BY is_required DESC, id''', (g.me['id'],))
    return render_template('inventory.html', items=items)


@app.post('/api/checklist/toggle')
@participant_required
def api_checklist_toggle():
    pid = g.me['id']
    iid = (request.get_json(silent=True) or {}).get('item_id')
    if not D.one('SELECT 1 FROM checklist_items WHERE id=?', (iid,)):
        return err('Barang tidak ditemukan', 404)
    if D.one('SELECT 1 FROM participant_checklist WHERE participant_id=? AND item_id=?', (pid, iid)):
        D.ex('DELETE FROM participant_checklist WHERE participant_id=? AND item_id=?', (pid, iid))
        checked = False
    else:
        D.ex('INSERT INTO participant_checklist VALUES(?,?,?)', (pid, iid, ts()))
        award(pid, 'check', iid, 5)
        checked = True
    total = D.val('SELECT COUNT(*) FROM checklist_items')
    c = D.val('SELECT COUNT(*) FROM participant_checklist WHERE participant_id=?', (pid,))
    if total and c >= total:
        award(pid, 'inventory_full', '1', 30, 10)
        grant_badge(pid, 'packing_master')
    return jsonify(ok=True, checked=checked, count=c, total=total, pct=int(c * 100 / total) if total else 0, fx=fxs())


@app.get('/lunch')
@participant_required
def lunch():
    ch = D.one('''SELECT f.name food, d.name drink, l.chosen_at FROM lunch_choices l
                  JOIN menu_food f ON f.id=l.food_id JOIN menu_drink d ON d.id=l.drink_id WHERE l.participant_id=?''', (g.me['id'],))
    foods = D.q('SELECT * FROM menu_food WHERE is_active=1 ORDER BY id')
    drinks = D.q('SELECT * FROM menu_drink WHERE is_active=1 ORDER BY id')
    return render_template('lunch.html', ch=ch, foods=foods, drinks=drinks, open=setting('lunch_open', '1') == '1')


@app.post('/api/lunch')
@participant_required
def api_lunch():
    if setting('lunch_open', '1') != '1':
        return err('Pemilihan menu sudah ditutup. Hubungi panitia.')
    d = request.get_json(silent=True) or {}
    if not D.one('SELECT 1 FROM menu_food WHERE id=? AND is_active=1', (d.get('food_id'),)) or \
            not D.one('SELECT 1 FROM menu_drink WHERE id=? AND is_active=1', (d.get('drink_id'),)):
        return err('Pilih makanan dan minuman dulu.')
    try:
        D.ex('INSERT INTO lunch_choices(participant_id,food_id,drink_id,chosen_at) VALUES(?,?,?,?)',
             (g.me['id'], d['food_id'], d['drink_id'], ts()))
    except sqlite3.IntegrityError:
        return err('Kamu sudah memilih menu. Pilihan tidak bisa diubah.')
    award(g.me['id'], 'lunch', '1', 20)
    grant_badge(g.me['id'], 'foodie')
    return jsonify(ok=True, redirect=u('/lunch'), fx=fxs())


@app.get('/treasure')
@participant_required
def treasure():
    pid = g.me['id']
    chs = D.q('''SELECT c.*, (SELECT COUNT(*) FROM photo_uploads p WHERE p.challenge_id=c.id AND p.participant_id=? AND p.status='approved') ok
                 FROM challenges c WHERE is_active=1 ORDER BY id''', (pid,))
    photos = D.q('''SELECT p.*, c.title FROM photo_uploads p LEFT JOIN challenges c ON c.id=p.challenge_id
                    WHERE p.participant_id=? ORDER BY p.id DESC''', (pid,))
    return render_template('treasure.html', chs=chs, photos=photos, unlocked=has_approved_photo(pid))


@app.post('/api/treasure/upload')
@participant_required
def api_upload():
    pid = g.me['id']
    f = request.files.get('photo')
    try:
        cid = int(request.form.get('challenge_id') or 0)
    except ValueError:
        cid = 0
    ch = D.one('SELECT * FROM challenges WHERE id=? AND is_active=1', (cid,))
    if not ch:
        return err('Pilih challenge dulu.')
    if not f or not f.filename:
        return err('Ambil foto atau pilih dari galeri dulu.')
    
    photo_count = D.val('SELECT COUNT(*) FROM photo_uploads WHERE participant_id=?', (pid,))
    if photo_count >= 10:
        return err('Batas maksimal 10 foto tercapai.')
        
    try:
        img = Image.open(f.stream)
        img = ImageOps.exif_transpose(img).convert('RGB')
    except Exception:
        return err('File bukan gambar yang bisa dibaca. Coba foto lain.')
    img.thumbnail((1280, 1280))
    fn = f'{pid}_{int(time.time())}_{secrets.token_hex(3)}.jpg'
    img.save(os.path.join(UPLOADS, fn), 'JPEG', quality=80, optimize=True)
    auto = setting('auto_approve', '1') == '1'
    D.ex('INSERT INTO photo_uploads(participant_id,challenge_id,file_path,uploaded_at,status,verified_by,verified_at) VALUES(?,?,?,?,?,?,?)',
         (pid, cid, fn, ts(), 'approved' if auto else 'pending', 'auto' if auto else None, ts() if auto else None))
    if auto:
        award(pid, 'photo', cid, ch['xp'], ch['treasure_points'])
        grant_badge(pid, 'treasure_hunter')
    return jsonify(ok=True, redirect=u('/treasure'), approved=auto, fx=fxs(),
                   msg='Foto diterima! Reward terbuka.' if auto else 'Foto terkirim, menunggu verifikasi panitia.')


@app.get('/media/<path:fn>')
def media(fn):
    owner = fn.split('_')[0]
    if not (session.get('admin') or (g.me and str(g.me['id']) == owner)):
        abort(403)
    return send_from_directory(UPLOADS, fn)


def _assignment(pid):
    return D.one('''SELECT ra.*, r.name, r.icon FROM reward_assignments ra JOIN rewards r ON r.id=ra.reward_id
                    WHERE ra.participant_id=?''', (pid,))


@app.get('/reward')
@participant_required
def reward():
    pid = g.me['id']
    a = _assignment(pid)
    icons = [r['icon'] for r in D.q('SELECT icon FROM rewards')] or ['🎁']
    return render_template('reward.html', unlocked=has_approved_photo(pid), a=a, icons=icons)


@app.post('/api/reward/open')
@participant_required
def api_reward_open():
    pid = g.me['id']
    if not has_approved_photo(pid):
        return err('Selesaikan Treasure Hunt dulu untuk membuka peti.')
    a = _assignment(pid)
    if not a:
        return err('Hadiah belum ditetapkan untukmu. Hubungi panitia.')
    if a['opened_at'] is None:
        D.ex("UPDATE reward_assignments SET opened_at=?, claim_status=CASE WHEN claim_status='claimed' THEN 'claimed' ELSE 'opened' END WHERE id=?", (ts(), a['id']))
        award(pid, 'reward', '1', 50)
        grant_badge(pid, 'loot_opener')
    decoys = [r['icon'] for r in D.q('SELECT icon FROM rewards')] or ['🎁']
    return jsonify(ok=True, name=a['name'], icon=a['icon'], code=a['claim_code'], claimed=a['claim_status'] == 'claimed',
                   decoys=decoys, fx=fxs())


@app.get('/quests')
@participant_required
def quests():
    pid = g.me['id']
    done = {r[0] for r in D.q('SELECT quest_id FROM participant_quests WHERE participant_id=?', (pid,))}
    qs = [dict(r, done=r['id'] in done) for r in D.q('SELECT * FROM quests ORDER BY is_secret, day, id')]
    return render_template('quests.html', qs=qs, td=today_day())


@app.post('/api/quest/<int:qid>/done')
@participant_required
def api_quest_done(qid):
    pid = g.me['id']
    qu = D.one('SELECT * FROM quests WHERE id=? AND is_secret=0', (qid,))
    if not qu:
        return err('Quest tidak ditemukan', 404)
    if qu['day'] > today_day():
        return err('Quest ini belum dibuka.')
    D.ex('INSERT OR IGNORE INTO participant_quests VALUES(?,?,?)', (pid, qid, ts()))
    award(pid, 'quest', qid, qu['xp'], qu['treasure_points'])
    return jsonify(ok=True, fx=fxs())


@app.post('/api/secret')
@participant_required
def api_secret():
    pid = g.me['id']
    code = ((request.get_json(silent=True) or {}).get('code') or '').strip().upper()
    qu = D.one('SELECT * FROM quests WHERE is_secret=1 AND UPPER(secret_code)=?', (code,)) if code else None
    if not qu:
        return err('Sandi salah. Coba cari petunjuk lagi.')
    D.ex('INSERT OR IGNORE INTO participant_quests VALUES(?,?,?)', (pid, qu['id'], ts()))
    new = award(pid, 'secret', qu['id'], qu['xp'], qu['treasure_points'])
    grant_badge(pid, 'secret_finder')
    return jsonify(ok=True, title=qu['title'], again=not new, fx=fxs())


@app.get('/ranking')
@participant_required
def ranking_page():
    visible = setting('ranking_visible', '1') == '1'
    rows = D.q('''SELECT p.id,p.name,p.avatar,p.xp,p.treasure_points tp,
                  (SELECT MAX(created_at) FROM xp_log WHERE participant_id=p.id) last
                  FROM participants p ORDER BY p.xp DESC, p.treasure_points DESC, last ASC, p.id ASC''')
    mine = next((i + 1 for i, r in enumerate(rows) if r['id'] == g.me['id']), None)
    return render_template('ranking.html', rows=rows[:10], visible=visible, mine=mine, n=len(rows))


@app.get('/profile')
@participant_required
def profile():
    pid = g.me['id']
    badges = D.q('''SELECT b.*, pb.earned_at FROM badges b
                    LEFT JOIN participant_badges pb ON pb.badge_id=b.id AND pb.participant_id=? ORDER BY b.id''', (pid,))
    return render_template('profile.html', badges=badges)


@app.post('/api/avatar')
@participant_required
def api_avatar():
    av = (request.get_json(silent=True) or {}).get('avatar')
    if av not in AV_KEYS:
        return err('Avatar tidak valid')
    D.ex('UPDATE participants SET avatar=? WHERE id=?', (av, g.me['id']))
    return jsonify(ok=True)


# ------------------------------------------------------------------ admin
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        adm = D.one('SELECT * FROM admin_users WHERE username=?', (request.form.get('username', '').strip(),))
        if adm and check_password_hash(adm['password_hash'], request.form.get('password', '')):
            session['admin'] = adm['username']
            session.permanent = True
            return redr('/admin')
        flash('Username atau password salah.', 'err')
    return render_template('admin/login.html')


@app.get('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redr('/admin/login')


def recap():
    foods = [dict(r) for r in D.q('SELECT f.id,f.name,COUNT(l.id) n FROM menu_food f LEFT JOIN lunch_choices l ON l.food_id=f.id GROUP BY f.id ORDER BY f.id')]
    drinks = [dict(r) for r in D.q('SELECT d.id,d.name,COUNT(l.id) n FROM menu_drink d LEFT JOIN lunch_choices l ON l.drink_id=d.id GROUP BY d.id ORDER BY d.id')]
    rows = [dict(r) for r in D.q('''SELECT p.id pid,p.name,p.division,f.name food,d.name drink,l.chosen_at FROM lunch_choices l
                                    JOIN participants p ON p.id=l.participant_id JOIN menu_food f ON f.id=l.food_id
                                    JOIN menu_drink d ON d.id=l.drink_id ORDER BY l.chosen_at DESC''')]
    pending = [dict(r) for r in D.q('SELECT name,division FROM participants WHERE id NOT IN (SELECT participant_id FROM lunch_choices) ORDER BY name')]
    return dict(foods=foods, drinks=drinks, rows=rows, pending=pending,
                total=D.val('SELECT COUNT(*) FROM participants'), filled=len(rows))


@app.get('/admin')
@admin_required
def admin_dash():
    st = dict(photos=D.val('SELECT COUNT(*) FROM photo_uploads'), opened=D.val('SELECT COUNT(*) FROM reward_assignments WHERE opened_at IS NOT NULL'),
              claimed=D.val("SELECT COUNT(*) FROM reward_assignments WHERE claim_status='claimed'"),
              logged=D.val('SELECT COUNT(*) FROM participants WHERE first_login IS NOT NULL'))
    return render_template('admin/dash.html', st=st)


@app.get('/admin/api/recap')
@admin_required
def admin_api_recap():
    return jsonify(recap())


@app.get('/admin/export.xlsx')
@admin_required
def admin_export():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    r = recap()
    wb = Workbook()
    hdr = lambda ws: [setattr(c, 'font', Font(bold=True, color='FFFFFF')) or setattr(c, 'fill', PatternFill('solid', fgColor='3B1FA8')) for c in ws[1]]
    ws = wb.active
    ws.title = 'Rekap Total'
    ws.append(['Kategori', 'Menu', 'Jumlah'])
    for f in r['foods']:
        ws.append(['Makanan', f['name'], f['n']])
    for d in r['drinks']:
        ws.append(['Minuman', d['name'], d['n']])
    ws.append([])
    ws.append(['Sudah memilih', '', r['filled']])
    ws.append(['Belum memilih', '', r['total'] - r['filled']])
    hdr(ws)
    w2 = wb.create_sheet('Detail Peserta')
    w2.append(['Nama', 'Divisi', 'Makanan', 'Minuman', 'Waktu pilih'])
    for x in r['rows']:
        w2.append([x['name'], x['division'], x['food'], x['drink'], x['chosen_at']])
    hdr(w2)
    w3 = wb.create_sheet('Belum Memilih')
    w3.append(['Nama', 'Divisi'])
    for x in r['pending']:
        w3.append([x['name'], x['division']])
    hdr(w3)
    for w in wb.worksheets:
        for col in w.columns:
            w.column_dimensions[col[0].column_letter].width = max(len(str(c.value or '')) for c in col) + 3
    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    return send_file(bio, as_attachment=True, download_name=f'rekap-menu-{now():%Y%m%d-%H%M}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@app.post('/admin/lunch/<int:pid>/reset')
@admin_required
def admin_lunch_reset(pid):
    D.ex('DELETE FROM lunch_choices WHERE participant_id=?', (pid,))
    flash('Pilihan menu direset. Peserta bisa memilih lagi.', 'ok')
    return redr('/admin')


# --- participants
@app.get('/admin/participants')
@admin_required
def admin_participants():
    rows = D.q('''SELECT p.*, ra.reward_id FROM participants p LEFT JOIN reward_assignments ra ON ra.participant_id=p.id ORDER BY p.name''')
    return render_template('admin/participants.html', rows=rows, rewards=D.q('SELECT * FROM rewards ORDER BY name'))


def _add_participant(name, division='', code='', reward=''):
    name = (name or '').strip()
    if not name:
        return None
    code = (code or '').strip().upper() or D.gen_code()
    try:
        cur = D.ex('INSERT INTO participants(code,name,division,created_at) VALUES(?,?,?,?)', (code, name, (division or '').strip(), ts()))
    except sqlite3.IntegrityError:
        return None
    if reward:
        rid = D.val('SELECT id FROM rewards WHERE LOWER(name)=LOWER(?)', (reward.strip(),))
        if not rid:
            rid = D.ex('INSERT INTO rewards(name,stock) VALUES(?,0)', (reward.strip(),)).lastrowid
        D.ex('INSERT INTO reward_assignments(participant_id,reward_id,claim_code) VALUES(?,?,?)', (cur.lastrowid, rid, claim_code()))
    return cur.lastrowid


@app.post('/admin/participants/add')
@admin_required
def admin_participants_add():
    f = request.form
    ok = _add_participant(f.get('name'), f.get('division'), f.get('code'), f.get('reward'))
    flash('Peserta ditambahkan.' if ok else 'Gagal: nama kosong atau kode sudah dipakai.', 'ok' if ok else 'err')
    return redr('/admin/participants')


@app.post('/admin/participants/import')
@admin_required
def admin_participants_import():
    f = request.files.get('file')
    if not f:
        flash('Pilih file CSV dulu.', 'err')
        return redr('/admin/participants')
    text = f.read().decode('utf-8-sig', errors='replace')
    sample = text[:2000]
    delim = ';' if sample.count(';') > sample.count(',') else ','
    rd = csv.DictReader(io.StringIO(text), delimiter=delim)
    rd.fieldnames = [(h or '').strip().lower() for h in (rd.fieldnames or [])]
    ok = bad = 0
    for r in rd:
        pid = _add_participant(r.get('name') or r.get('nama'), r.get('division') or r.get('divisi'), r.get('code') or r.get('kode'),
                               r.get('reward') or r.get('hadiah'))
        ok, bad = (ok + 1, bad) if pid else (ok, bad + 1)
    flash(f'Import selesai: {ok} berhasil, {bad} dilewati.', 'ok')
    return redr('/admin/participants')


@app.get('/admin/participants.csv')
@admin_required
def admin_participants_csv():
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['name', 'division', 'code', 'reward'])
    for r in D.q('''SELECT p.name,p.division,p.code,rw.name reward FROM participants p
                    LEFT JOIN reward_assignments ra ON ra.participant_id=p.id LEFT JOIN rewards rw ON rw.id=ra.reward_id ORDER BY p.name'''):
        w.writerow([r['name'], r['division'], r['code'], r['reward'] or ''])
    return send_file(io.BytesIO(out.getvalue().encode('utf-8-sig')), as_attachment=True, download_name='peserta-kode.csv', mimetype='text/csv')


@app.post('/admin/participants/<int:pid>/<act>')
@admin_required
def admin_participant_act(pid, act):
    if act == 'newcode':
        D.ex('UPDATE participants SET code=?, session_epoch=session_epoch+1 WHERE id=?', (D.gen_code(D.conn()), pid))
        flash('Kode diganti. Perangkat lama otomatis keluar.', 'ok')
    elif act == 'delete':
        for t in ('participant_agenda', 'participant_checklist', 'participant_quests', 'participant_badges'):
            D.ex(f'DELETE FROM {t} WHERE participant_id=?', (pid,))
        D.ex('DELETE FROM participants WHERE id=?', (pid,))
        flash('Peserta dihapus.', 'ok')
    elif act == 'reward':
        rid = request.form.get('reward_id')
        if rid:
            D.ex('''INSERT INTO reward_assignments(participant_id,reward_id,claim_code) VALUES(?,?,?)
                    ON CONFLICT(participant_id) DO UPDATE SET reward_id=excluded.reward_id''', (pid, rid, claim_code()))
        else:
            D.ex('DELETE FROM reward_assignments WHERE participant_id=?', (pid,))
        flash('Hadiah peserta diperbarui.', 'ok')
    return redr(request.referrer or '/admin/participants')


# --- menu
@app.get('/admin/menu')
@admin_required
def admin_menu():
    return render_template('admin/menu.html', foods=D.q('SELECT * FROM menu_food ORDER BY id'), drinks=D.q('SELECT * FROM menu_drink ORDER BY id'))


@app.post('/admin/menu/<kind>/<act>')
@admin_required
def admin_menu_act(kind, act):
    t = {'food': 'menu_food', 'drink': 'menu_drink'}.get(kind)
    if not t:
        abort(404)
    if act == 'add' and request.form.get('name', '').strip():
        if kind == 'food':
            D.ex('INSERT INTO menu_food(name,description) VALUES(?,?)', (request.form['name'].strip(), request.form.get('description', '')))
        else:
            D.ex('INSERT INTO menu_drink(name) VALUES(?)', (request.form['name'].strip(),))
    elif act == 'toggle':
        D.ex(f'UPDATE {t} SET is_active=1-is_active WHERE id=?', (request.form.get('id'),))
    elif act == 'delete':
        col = 'food_id' if kind == 'food' else 'drink_id'
        if D.val(f'SELECT 1 FROM lunch_choices WHERE {col}=?', (request.form.get('id'),)):
            flash('Menu sudah dipilih peserta, nonaktifkan saja.', 'err')
        else:
            D.ex(f'DELETE FROM {t} WHERE id=?', (request.form.get('id'),))
    return redr('/admin/menu')


# --- generic content (agenda, rules, checklist, challenges, quests)
KINDS = {
    'agenda': dict(title='Rundown', table='agenda', order='day,start_time', fields=[
        ('day', 'Hari', 'number'), ('start_time', 'Mulai', 'time'), ('end_time', 'Selesai', 'time'), ('title', 'Kegiatan', 'text'),
        ('category', 'Kategori', CATS), ('location', 'Lokasi', 'text'), ('note', 'Catatan', 'text')]),
    'rules': dict(title="Do's & Don'ts", table='rules_cards', order='type DESC,id', fields=[
        ('type', 'Tipe', ['do', 'dont']), ('title', 'Judul', 'text'), ('detail', 'Penjelasan', 'text'), ('rarity', 'Rarity (1-3)', 'number')]),
    'checklist': dict(title='Checklist Barang', table='checklist_items', order='id', fields=[
        ('name', 'Nama barang', 'text'), ('is_required', 'Wajib (1/0)', 'number')]),
    'challenges': dict(title='Challenge Treasure Hunt', table='challenges', order='id', fields=[
        ('title', 'Judul', 'text'), ('description', 'Deskripsi', 'text'), ('xp', 'XP', 'number'), ('treasure_points', 'Treasure Points', 'number')]),
    'quests': dict(title='Quest & Secret Mission', table='quests', order='is_secret,day,id', fields=[
        ('day', 'Hari (0=secret)', 'number'), ('title', 'Judul', 'text'), ('xp', 'XP', 'number'), ('treasure_points', 'TP', 'number'),
        ('is_secret', 'Secret (1/0)', 'number'), ('secret_code', 'Sandi secret', 'text'), ('hint', 'Petunjuk', 'text')]),
}


@app.get('/admin/c/<kind>')
@admin_required
def admin_content(kind):
    k = KINDS.get(kind) or abort(404)
    rows = D.q(f"SELECT * FROM {k['table']} ORDER BY {k['order']}")
    return render_template('admin/content.html', kind=kind, k=k, rows=rows)


@app.post('/admin/c/<kind>/<act>')
@admin_required
def admin_content_act(kind, act):
    k = KINDS.get(kind) or abort(404)
    if act == 'add':
        cols, vals = [], []
        for name, _l, typ in k['fields']:
            v = request.form.get(name, '').strip()
            if typ == 'number':
                v = int(v) if v.lstrip('-').isdigit() else 0
            cols.append(name)
            vals.append(v)
        D.ex(f"INSERT INTO {k['table']}({','.join(cols)}) VALUES({','.join('?' * len(cols))})", vals)
        flash('Data ditambahkan.', 'ok')
    elif act == 'delete':
        D.ex(f"DELETE FROM {k['table']} WHERE id=?", (request.form.get('id'),))
        flash('Data dihapus.', 'ok')
    return redr(f'/admin/c/{kind}')


# --- photos
def _revoke_photo_xp(pid, cid):
    if not D.val("SELECT 1 FROM photo_uploads WHERE participant_id=? AND challenge_id=? AND status='approved'", (pid, cid)):
        D.ex("DELETE FROM xp_log WHERE participant_id=? AND source='photo' AND source_id=?", (pid, str(cid)))
        recompute(pid)


@app.get('/admin/photos')
@admin_required
def admin_photos():
    st = request.args.get('status', '')
    sql = '''SELECT p.*, pt.name, c.title FROM photo_uploads p JOIN participants pt ON pt.id=p.participant_id
             LEFT JOIN challenges c ON c.id=p.challenge_id'''
    rows = D.q(sql + (' WHERE p.status=?' if st else '') + ' ORDER BY p.id DESC LIMIT 300', (st,) if st else ())
    return render_template('admin/photos.html', rows=rows, st=st)


@app.post('/admin/photos/<int:fid>/<act>')
@admin_required
def admin_photo_act(fid, act):
    p = D.one('SELECT * FROM photo_uploads WHERE id=?', (fid,))
    if not p:
        abort(404)
    if act == 'approve':
        D.ex("UPDATE photo_uploads SET status='approved',verified_by=?,verified_at=?,reject_reason=NULL WHERE id=?", (session['admin'], ts(), fid))
        ch = D.one('SELECT * FROM challenges WHERE id=?', (p['challenge_id'],))
        if ch:
            award(p['participant_id'], 'photo', ch['id'], ch['xp'], ch['treasure_points'])
        grant_badge(p['participant_id'], 'treasure_hunter')
    elif act == 'reject':
        D.ex("UPDATE photo_uploads SET status='rejected',verified_by=?,verified_at=?,reject_reason=? WHERE id=?",
             (session['admin'], ts(), request.form.get('reason', '').strip() or 'Foto tidak sesuai challenge', fid))
        _revoke_photo_xp(p['participant_id'], p['challenge_id'])
    elif act == 'delete':
        D.ex('DELETE FROM photo_uploads WHERE id=?', (fid,))
        try:
            os.remove(os.path.join(UPLOADS, p['file_path']))
        except OSError:
            pass
        _revoke_photo_xp(p['participant_id'], p['challenge_id'])
    return redr(request.referrer or '/admin/photos')


# --- rewards
@app.get('/admin/rewards')
@admin_required
def admin_rewards():
    rewards = D.q('''SELECT r.*, (SELECT COUNT(*) FROM reward_assignments WHERE reward_id=r.id) used FROM rewards r ORDER BY r.id''')
    maps = D.q('''SELECT ra.*, p.name pname, p.id pid, r.name rname, r.icon,
                  (SELECT 1 FROM photo_uploads ph WHERE ph.participant_id=p.id AND ph.status='approved' LIMIT 1) unlocked
                  FROM reward_assignments ra JOIN participants p ON p.id=ra.participant_id JOIN rewards r ON r.id=ra.reward_id ORDER BY p.name''')
    nomap = D.val('SELECT COUNT(*) FROM participants WHERE id NOT IN (SELECT participant_id FROM reward_assignments)')
    return render_template('admin/rewards.html', rewards=rewards, maps=maps, nomap=nomap)


@app.post('/admin/rewards/<act>')
@admin_required
def admin_rewards_act(act):
    f = request.form
    if act == 'add' and f.get('name', '').strip():
        D.ex('INSERT INTO rewards(name,icon,stock) VALUES(?,?,?)', (f['name'].strip(), f.get('icon') or '🎁', int(f.get('stock') or 0)))
    elif act == 'delete':
        if D.val('SELECT 1 FROM reward_assignments WHERE reward_id=?', (f.get('id'),)):
            flash('Hadiah sudah dipetakan ke peserta.', 'err')
        else:
            D.ex('DELETE FROM rewards WHERE id=?', (f.get('id'),))
    elif act == 'claim':
        a = D.one('SELECT * FROM reward_assignments WHERE UPPER(claim_code)=?', ((f.get('code') or '').strip().upper(),))
        if not a:
            flash('Kode klaim tidak ditemukan.', 'err')
        elif a['claim_status'] == 'claimed':
            flash(f'Sudah diklaim pada {a["claimed_at"]}.', 'err')
        elif a['opened_at'] is None:
            flash('Peserta belum membuka loot box.', 'err')
        else:
            D.ex("UPDATE reward_assignments SET claim_status='claimed',claimed_at=?,claimed_by=? WHERE id=?", (ts(), session['admin'], a['id']))
            flash('Hadiah ditandai sudah diklaim.', 'ok')
    elif act == 'unclaim':
        D.ex("UPDATE reward_assignments SET claim_status='opened',claimed_at=NULL,claimed_by=NULL WHERE id=?", (f.get('id'),))
    elif act == 'autofill':
        left = []
        for r in D.q('SELECT r.id, r.stock-(SELECT COUNT(*) FROM reward_assignments WHERE reward_id=r.id) free FROM rewards r'):
            left += [r['id']] * max(r['free'], 0)
        random.shuffle(left)
        todo = D.q('SELECT id FROM participants WHERE id NOT IN (SELECT participant_id FROM reward_assignments)')
        n = 0
        for p, rid in zip(todo, left):
            D.ex('INSERT INTO reward_assignments(participant_id,reward_id,claim_code) VALUES(?,?,?)', (p['id'], rid, claim_code()))
            n += 1
        flash(f'{n} peserta diisi hadiah otomatis dari sisa stok ({len(todo) - n} belum kebagian).', 'ok')
    return redr('/admin/rewards')


# --- settings / backup
@app.route('/admin/settings', methods=['GET', 'POST'])
@admin_required
def admin_settings():
    if request.method == 'POST':
        f = request.form
        for k in ('event_name', 'event_start'):
            if f.get(k):
                set_setting(k, f[k].strip())
        for k in ('lunch_open', 'auto_approve', 'ranking_visible', 'strict_map'):
            set_setting(k, '1' if f.get(k) else '0')
        if f.get('new_password'):
            D.ex('UPDATE admin_users SET password_hash=? WHERE username=?', (generate_password_hash(f['new_password']), session['admin']))
        flash('Pengaturan disimpan.', 'ok')
        return redr('/admin/settings')
    return render_template('admin/settings.html')


@app.post('/admin/top3')
@admin_required
def admin_top3():
    rows = D.q('''SELECT id FROM participants WHERE xp>0 ORDER BY xp DESC, treasure_points DESC LIMIT 3''')
    for r in rows:
        grant_badge(r['id'], 'top3')
    flash(f'Badge Top 3 diberikan ke {len(rows)} peserta.', 'ok')
    return redr('/admin/settings')


def snapshot_db(dest):
    src = D.connect()
    out = sqlite3.connect(dest)
    src.backup(out)
    out.close()
    src.close()


@app.get('/admin/backup.zip')
@admin_required
def admin_backup():
    tmp = tempfile.mkdtemp()
    try:
        snapshot_db(os.path.join(tmp, 'app.db'))
        bio = io.BytesIO()
        with zipfile.ZipFile(bio, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(os.path.join(tmp, 'app.db'), 'app.db')
            for fn in os.listdir(UPLOADS):
                z.write(os.path.join(UPLOADS, fn), 'uploads/' + fn)
        bio.seek(0)
        return send_file(bio, as_attachment=True, download_name=f'backup-{now():%Y%m%d-%H%M}.zip', mimetype='application/zip')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def backup_loop(dest, every=600):
    """Optional: copy DB + photos to a folder (e.g. synced Google Drive / OneDrive / Dropbox)."""
    os.makedirs(os.path.join(dest, 'uploads'), exist_ok=True)
    while True:
        try:
            snapshot_db(os.path.join(dest, 'app.db'))
            for fn in os.listdir(UPLOADS):
                t = os.path.join(dest, 'uploads', fn)
                if not os.path.exists(t):
                    shutil.copy2(os.path.join(UPLOADS, fn), t)
        except Exception as e:
            print('backup error:', e)
        time.sleep(every)


if __name__ == '__main__':
    from waitress import serve
    port = int(os.environ.get('PORT', 8000))
    
    print(f'\n  Recharge & Reconnect berjalan di http://0.0.0.0:{port}')
    print('  Admin: /admin  (default admin / admin123 - GANTI di Pengaturan)\n')
    serve(app, host='0.0.0.0', port=port, threads=8)
