/* Pixel sprites 8x8 - drawn as crisp SVG */
(function () {
  const PAL = { k: '#1a1a40', s: '#ffcf9f', w: '#ffffff', b: '#00e5ff', p: '#b14cff', y: '#ffe600',
    g: '#39ff14', r: '#ff3860', d: '#8a8ac0', o: '#ff9a3c', n: '#9a6a3a' };
  const S = {
    knight: ['...rr...', '..dddd..', '.dddddd.', '.dksskd.', '.dssssd.', '..dddd..', '.bbbbbb.', 'bbbbbbbb'],
    ninja: ['..kkkk..', '.kkkkkk.', '.kwkkwk.', '.kkkkkk.', '..kkkk..', '..rrrr..', '.kkkkkk.', 'kkkkkkkk'],
    robot: ['...yy...', '...dd...', '.dddddd.', '.dgddgd.', '.dddddd.', '.dkkkkd.', '..dddd..', '.dddddd.'],
    astro: ['..wwww..', '.wwwwww.', '.wkkkkw.', '.wkbbkw.', '.wkkkkw.', '..wwww..', '.wrwwww.', 'wwwwwwww'],
    wizard: ['...pp...', '..pppp..', '.pppyyp.', 'pppppppp', '.skssks.', '.swwwws.', '..wwww..', '...ww...'],
    cat: ['.o....o.', '.oo..oo.', '.oooooo.', '.ogoogo.', '.oorroo.', '.owwwwo.', '..oooo..', '.oo..oo.'],
    bus: ['........', '.yyyyyy.', '.ybybyb.', '.yyyyyy.', '.yyyyyy.', '.dyyyyd.', '..kk.kk.', '........'],
    food: ['..oooo..', '.oooooo.', 'gggggggg', 'rrrrrrrr', 'nnnnnnnn', '.oooooo.', '..oooo..', '........'],
    game: ['........', '.dddddd.', 'dddddddd', 'dkdddgrd', 'dddddddd', '.dd..dd.', '........', '........'],
    star: ['...yy...', '...yy...', 'yyyyyyyy', '.yyyyyy.', '..yyyy..', '.yyyyyy.', '.yy..yy.', '........'],
    lock: ['..dddd..', '.d....d.', '.d....d.', 'yyyyyyyy', 'yyykkyyy', 'yyykkyyy', 'yyyyyyyy', 'yyyyyyyy'],
    chest: ['........', '.nnnnnn.', 'nnnnnnnn', 'yyyyyyyy', 'nnnyynnn', 'nnnyynnn', 'nnnnnnnn', '........'],
    trophy: ['.yyyyyy.', 'yyyyyyyy', 'y.yyyy.y', '.yyyyyy.', '..yyyy..', '...yy...', '..yyyy..', '.yyyyyy.'],
    bag: ['..nnnn..', '..n..n..', '.nnnnnn.', 'nnnyynnn', 'nnnyynnn', 'nnnnnnnn', 'nnnnnnnn', '.nnnnnn.'],
    check: ['........', '.......g', '......gg', 'g....gg.', 'gg..gg..', '.gggg...', '..gg....', '........'],
    flag: ['.rrrrr..', '.rrrrr..', '.rrrrr..', '.d......', '.d......', '.d......', '.d......', 'dddd....'],
    cam: ['........', '..dddd..', 'dddddddd', 'ddwwwwdd', 'ddwkkwdd', 'ddwwwwdd', 'dddddddd', '........'],
    coin: ['..yyyy..', '.yyyyyy.', 'yyywwyyy', 'yyywyyyy', 'yyywyyyy', 'yyyyyyyy', '.yyyyyy.', '..yyyy..'],
    map: ['........', 'wwww....', 'wbbw.ww.', 'wbbwwggw', 'wwwwwggw', '....wwww', '........', '........'],
    user: ['..kkkk..', '.kssssk.', '.kssssk.', '..kkkk..', '.bbbbbb.', 'bbbbbbbb', 'bbbbbbbb', '........'],
  };
  function svg(name) {
    const m = S[name] || S.star;
    let out = '<svg viewBox="0 0 8 8" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" aria-hidden="true">';
    for (let y = 0; y < 8; y++) {
      let x = 0;
      while (x < 8) {
        const c = m[y][x];
        if (c === '.') { x++; continue; }
        let e = x;
        while (e < 8 && m[y][e] === c) e++;
        out += `<rect x="${x}" y="${y}" width="${e - x}" height="1" fill="${PAL[c]}"/>`;
        x = e;
      }
    }
    return out + '</svg>';
  }
  function paint(root) {
    (root || document).querySelectorAll('[data-sprite]').forEach(el => { el.innerHTML = svg(el.dataset.sprite); });
  }
  window.RRSprite = { svg, paint, names: Object.keys(S) };
  document.addEventListener('DOMContentLoaded', () => paint());
})();
