@echo off
cd /d %~dp0
set SEED_DEMO=0
set ADMIN_USER=panitia
set ADMIN_PASS=passwordkuat123
set BACKUP_DIR=D:\outing
python -m pip install -r requirements.txt
python app.py
pause
