# Recharge & Reconnect - Retro Arcade Outing App

Aplikasi web mobile-first bertema game jadul untuk outing tim (16-17 Oktober 2026).
Stack: **Python Flask + Waitress + SQLite** (tanpa build step, tanpa Node.js).

## Jalankan (Windows / Linux / Mac)

```
pip install -r requirements.txt
python app.py
```
Buka `http://localhost:8000` (peserta) dan `http://localhost:8000/admin` (admin).

- Admin default: `admin` / `admin123`. **Ganti di Admin > Setelan** (atau set env `ADMIN_USER`, `ADMIN_PASS` sebelum run pertama).
- Run pertama membuat database `data/app.db` berisi **data demo** (8 peserta kode `DEMO01`-`DEMO08`, agenda contoh, menu, hadiah).
  Untuk acara sungguhan: hapus `data/app.db*` lalu jalankan dengan `SEED_DEMO=0` (Windows: `set SEED_DEMO=0`), kemudian isi data lewat halaman admin.

## Alur penggunaan

1. **Admin** import peserta (CSV: `name,division,code,reward`) atau tambah manual. Kode dibuat otomatis bila kosong. Unduh daftar kode (CSV) dan bagikan lewat WhatsApp.
2. **Peserta** buka link, pilih avatar, masukkan kode **sekali**. Sesi permanen (cookie 1 tahun + localStorage), sehingga otomatis masuk di kunjungan berikutnya.
3. Admin mengisi Rundown, Do's & Don'ts, Checklist, Challenge, Quest di menu **Konten**; menu makan siang di **Menu**; hadiah di **Hadiah**.
4. Hari H: pantau **Rekap** (update tiap 5 detik, export Excel), tandai hadiah **diklaim** dengan kode klaim.

## Fitur

Landing + opening animation + countdown + avatar, Mission Map, Event Rundown (quest log), Do's & Don'ts (kartu item), Inventory Bag (checklist + %),
Lunch Day 2 (satu kali pilih, dijamin UNIQUE di database), Rekap + grafik + Excel, Treasure Hunt (kamera/galeri, preview, kompres, auto-approve),
Reward Engine (hadiah dari database, loot box hanya animasi), XP, level, badge, ranking, daily quest, secret mission, treasure points, panel admin lengkap.

## Reward Engine

Hadiah **ditetapkan lebih dulu** di tabel `reward_assignments` (satu peserta satu hadiah). Setelah ada foto `approved`, peserta bisa membuka peti. Server
mengembalikan hadiah yang sudah ditetapkan; animasi acak di browser murni visual. Status: `assigned -> opened -> claimed`.

## Deploy agar bisa diakses semua peserta

Kamera browser **wajib HTTPS**. Pilihan termudah:
- **VPS/cloud kecil** + domain + reverse proxy (Caddy otomatis HTTPS). Set `COOKIE_SECURE=1`.
- **Laptop panitia** + Cloudflare Tunnel: `cloudflared tunnel --url http://localhost:8000` (dapat alamat https gratis).

Backup: Admin > Setelan > Unduh Backup (DB + foto). Backup otomatis ke folder cloud-sync (Google Drive/OneDrive/Dropbox):
set `BACKUP_DIR=C:\path\folder` sebelum `python app.py` (salinan tiap 10 menit).

## Variabel lingkungan

`PORT` (8000), `SECRET_KEY`, `ADMIN_USER`, `ADMIN_PASS`, `SEED_DEMO` (1/0), `COOKIE_SECURE` (1/0), `BACKUP_DIR`, `RR_DB`, `RR_UPLOADS`.

## Catatan

- Font Press Start 2P dan VT323 dimuat dari Google Fonts; tanpa internet tampilan memakai font monospace cadangan. Untuk offline, unduh font dan taruh di `static/`.
- Quest harian terkunci sampai hari acara (Day 1 = tanggal mulai di Setelan). Ubah tanggal bila ingin uji coba.
- Mission Map default terbuka semua agar tidak menghambat peserta; aktifkan mode berurutan di Setelan jika diinginkan.
- Foto otomatis disetujui (bisa dimatikan di Setelan); admin bisa menolak foto belakangan dan XP otomatis ditarik.
