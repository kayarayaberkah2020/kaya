"""Database layer (SQLite, WAL) + schema + demo seed."""
import os, sqlite3, secrets
from flask import g
from werkzeug.security import generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('RR_DB') or os.path.join(BASE, 'data', 'app.db')
ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

SCHEMA = """
CREATE TABLE IF NOT EXISTS participants(
 id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, division TEXT,
 avatar TEXT DEFAULT 'knight', xp INTEGER DEFAULT 0, treasure_points INTEGER DEFAULT 0,
 session_epoch INTEGER DEFAULT 0, first_login TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS menu_food(id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT, is_active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS menu_drink(id INTEGER PRIMARY KEY, name TEXT NOT NULL, is_active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS lunch_choices(
 id INTEGER PRIMARY KEY,
 participant_id INTEGER UNIQUE NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
 food_id INTEGER NOT NULL REFERENCES menu_food(id),
 drink_id INTEGER NOT NULL REFERENCES menu_drink(id), chosen_at TEXT);
CREATE TABLE IF NOT EXISTS agenda(id INTEGER PRIMARY KEY, day INTEGER, start_time TEXT, end_time TEXT,
 title TEXT, category TEXT, location TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS participant_agenda(participant_id INTEGER, agenda_id INTEGER, opened_at TEXT,
 PRIMARY KEY(participant_id, agenda_id));
CREATE TABLE IF NOT EXISTS rules_cards(id INTEGER PRIMARY KEY, type TEXT CHECK(type IN ('do','dont')),
 title TEXT, detail TEXT, rarity INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS checklist_items(id INTEGER PRIMARY KEY, name TEXT, is_required INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS participant_checklist(participant_id INTEGER, item_id INTEGER, checked_at TEXT,
 PRIMARY KEY(participant_id, item_id));
CREATE TABLE IF NOT EXISTS challenges(id INTEGER PRIMARY KEY, title TEXT, description TEXT,
 xp INTEGER DEFAULT 100, treasure_points INTEGER DEFAULT 50, is_active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS photo_uploads(
 id INTEGER PRIMARY KEY,
 participant_id INTEGER NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
 challenge_id INTEGER, file_path TEXT NOT NULL, uploaded_at TEXT,
 status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 verified_by TEXT, verified_at TEXT, reject_reason TEXT);
CREATE TABLE IF NOT EXISTS rewards(id INTEGER PRIMARY KEY, name TEXT NOT NULL, icon TEXT DEFAULT '🎁', stock INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS reward_assignments(
 id INTEGER PRIMARY KEY,
 participant_id INTEGER UNIQUE NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
 reward_id INTEGER NOT NULL REFERENCES rewards(id),
 claim_code TEXT UNIQUE,
 claim_status TEXT DEFAULT 'assigned' CHECK(claim_status IN ('assigned','opened','claimed')),
 opened_at TEXT, claimed_at TEXT, claimed_by TEXT);
CREATE TABLE IF NOT EXISTS badges(id INTEGER PRIMARY KEY, code TEXT UNIQUE, name TEXT, description TEXT, sprite TEXT);
CREATE TABLE IF NOT EXISTS participant_badges(participant_id INTEGER, badge_id INTEGER, earned_at TEXT,
 PRIMARY KEY(participant_id, badge_id));
CREATE TABLE IF NOT EXISTS quests(id INTEGER PRIMARY KEY, day INTEGER, title TEXT, xp INTEGER DEFAULT 20,
 treasure_points INTEGER DEFAULT 0, is_secret INTEGER DEFAULT 0, secret_code TEXT, hint TEXT);
CREATE TABLE IF NOT EXISTS participant_quests(participant_id INTEGER, quest_id INTEGER, completed_at TEXT,
 PRIMARY KEY(participant_id, quest_id));
CREATE TABLE IF NOT EXISTS xp_log(
 id INTEGER PRIMARY KEY,
 participant_id INTEGER NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
 source TEXT, source_id TEXT, xp INTEGER DEFAULT 0, tp INTEGER DEFAULT 0, created_at TEXT,
 UNIQUE(participant_id, source, source_id));
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS admin_users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT);
"""

DEFAULT_SETTINGS = {
    'event_name': 'Recharge & Reconnect',
    'event_start': '2026-10-16T06:00',
    'lunch_open': '1',
    'auto_approve': '1',
    'ranking_visible': '1',
    'strict_map': '0',
}

BADGES = [
    ('player_one', 'Player One', 'Login pertama kali', 'star'),
    ('early_bird', 'Early Bird', 'Login sebelum acara dimulai', 'flag'),
    ('rule_keeper', 'Rule Keeper', 'Membuka semua kartu Do\'s & Don\'ts', 'check'),
    ('packing_master', 'Packing Master', 'Inventory bag 100%', 'bag'),
    ('foodie', 'Foodie', 'Memilih menu makan siang', 'food'),
    ('treasure_hunter', 'Treasure Hunter', 'Upload foto Treasure Hunt pertama', 'cam'),
    ('secret_finder', 'Secret Finder', 'Menemukan secret mission', 'lock'),
    ('loot_opener', 'Loot Opener', 'Membuka loot box', 'chest'),
    ('top3', 'Top 3', 'Peringkat 3 besar', 'trophy'),
]


def connect():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=20000')
    c.execute('PRAGMA synchronous=NORMAL')
    return c


def conn():
    if 'db' not in g:
        g.db = connect()
    return g.db


def close(_e=None):
    c = g.pop('db', None)
    if c is not None:
        c.close()


def q(sql, a=()):
    return conn().execute(sql, a).fetchall()


def one(sql, a=()):
    return conn().execute(sql, a).fetchone()


def val(sql, a=()):
    r = one(sql, a)
    return r[0] if r else None


def ex(sql, a=()):
    c = conn()
    cur = c.execute(sql, a)
    c.commit()
    return cur


def gen_code(c=None, n=6):
    own = c is None
    c = c or conn()
    while True:
        code = ''.join(secrets.choice(ALPHA) for _ in range(n))
        if not c.execute('SELECT 1 FROM participants WHERE code=?', (code,)).fetchone():
            return code


def init_db():
    c = connect()
    c.executescript(SCHEMA)
    if not c.execute('SELECT 1 FROM settings LIMIT 1').fetchone():
        for k, v in DEFAULT_SETTINGS.items():
            c.execute('INSERT INTO settings VALUES(?,?)', (k, v))
    for b in BADGES:
        c.execute('INSERT OR IGNORE INTO badges(code,name,description,sprite) VALUES(?,?,?,?)', b)
    if not c.execute('SELECT 1 FROM admin_users').fetchone():
        u = os.environ.get('ADMIN_USER', 'admin')
        p = os.environ.get('ADMIN_PASS', 'admin123')
        c.execute('INSERT INTO admin_users(username,password_hash) VALUES(?,?)', (u, generate_password_hash(p)))
    seeded = c.execute("SELECT 1 FROM settings WHERE key='seeded'").fetchone()
    if not seeded and os.environ.get('SEED_DEMO', '1') != '0':
        seed_demo(c)
    c.commit()
    c.close()


def seed_demo(c):
    c.execute("INSERT OR REPLACE INTO settings VALUES('seeded','1')")
    ag = [
        (1, '06:00', '07:00', 'Kumpul & registrasi', 'activity', 'Titik kumpul (sesuai info panitia)', 'Datang 15 menit lebih awal. Tunjukkan kode peserta ke panitia.'),
        (1, '07:00', '10:30', 'Perjalanan menuju Garut', 'vehicle', 'Bus rombongan', 'Duduk sesuai nomor bus. Siapkan snack dan obat anti mabuk.'),
        (1, '10:30', '11:30', 'Tiba & check-in', 'activity', 'Lokasi penginapan', 'Ambil kunci kamar dan simpan barang.'),
        (1, '12:00', '13:00', 'Makan siang', 'meal', 'Area makan', 'Menu disiapkan panitia.'),
        (1, '13:30', '16:00', 'Team building games', 'game', 'Lapangan', 'Pakai pakaian olahraga dan sepatu nyaman.'),
        (1, '16:00', '18:00', 'Istirahat bebas', 'rest', 'Penginapan', 'Waktunya recharge.'),
        (1, '19:00', '20:00', 'Makan malam', 'meal', 'Area makan', 'Kumpul bersama tim.'),
        (1, '20:00', '22:00', 'Malam keakraban', 'game', 'Area api unggun', 'Game seru dan hiburan bersama.'),
        (2, '06:00', '07:30', 'Sarapan', 'meal', 'Area makan', 'Isi tenaga sebelum petualangan.'),
        (2, '08:00', '11:30', 'Treasure Hunt Garut', 'game', 'Sekitar kota Garut', 'Cari kuliner, ikon, dan alun-alun Garut lalu upload fotonya di aplikasi.'),
        (2, '12:00', '13:00', 'Makan siang', 'meal', 'Area makan', 'Menu sesuai pilihan di aplikasi.'),
        (2, '13:30', '14:30', 'Sesi Recharge & Reconnect', 'activity', 'Aula', 'Berbagi cerita dan pesan untuk tim.'),
        (2, '15:00', '18:00', 'Perjalanan pulang', 'vehicle', 'Bus rombongan', 'Cek barang bawaan sebelum naik bus.'),
    ]
    c.executemany('INSERT INTO agenda(day,start_time,end_time,title,category,location,note) VALUES(?,?,?,?,?,?,?)', ag)
    rules = [
        ('do', 'Datang tepat waktu', 'Kumpul 15 menit sebelum jadwal supaya semua bisa berangkat bersama.', 1),
        ('do', 'Jaga kebersihan', 'Bawa sampahmu kembali. Alam Garut dijaga bersama.', 1),
        ('do', 'Bawa botol minum', 'Hemat plastik dan tetap terhidrasi.', 2),
        ('do', 'Saling jaga teman', 'Cek rekan satu tim, terutama saat perjalanan dan games.', 3),
        ('dont', 'Jangan tinggalkan rombongan', 'Selalu izin ke panitia sebelum pergi dari area acara.', 2),
        ('dont', 'Jangan buang sampah sembarangan', 'Gunakan tempat sampah atau bawa pulang.', 1),
        ('dont', 'Jangan abaikan arahan panitia', 'Arahan dibuat demi keselamatan semua peserta.', 2),
        ('dont', 'Jangan main di area berbahaya', 'Hindari tepi jurang, sungai deras, atau area terlarang.', 3),
    ]
    c.executemany('INSERT INTO rules_cards(type,title,detail,rarity) VALUES(?,?,?,?)', rules)
    for n, r in [('KTP / identitas', 1), ('Pakaian ganti', 1), ('Jaket', 1), ('Obat pribadi', 1), ('Charger & powerbank', 1),
                 ('Perlengkapan mandi', 1), ('Sepatu nyaman', 1), ('Botol minum', 1), ('Jas hujan / payung', 0), ('Uang tunai', 0)]:
        c.execute('INSERT INTO checklist_items(name,is_required) VALUES(?,?)', (n, r))
    for t, d in [('Kuliner khas Garut', 'Foto dodol, soto Garut, atau kuliner khas lainnya.'),
                 ('Alun-alun Garut', 'Foto dirimu atau timmu di Alun-alun Garut.'),
                 ('Ikon kota Garut', 'Foto landmark atau ikon yang identik dengan Garut.'),
                 ('Spot favorit tim', 'Foto tim di spot wisata Garut pilihanmu.')]:
        c.execute('INSERT INTO challenges(title,description,xp,treasure_points) VALUES(?,?,100,50)', (t, d))
    c.executemany('INSERT INTO quests(day,title,xp,treasure_points,is_secret,secret_code,hint) VALUES(?,?,?,?,?,?,?)', [
        (1, 'Selfie bareng 3 rekan dari divisi lain', 20, 10, 0, None, None),
        (1, 'Ucapkan terima kasih ke satu rekan', 20, 10, 0, None, None),
        (2, 'Foto tim sebelum pulang', 30, 10, 0, None, None),
        (0, 'Secret Mission: Kata Sandi Rahasia', 150, 100, 1, 'RECHARGE', 'Sandi tersembunyi di salah satu kegiatan. Tanyakan petunjuk ke panitia.'),
    ])
    for n, d in [('Menu A - Nasi Timbel Ayam', 'Nasi timbel, ayam goreng, lalapan, sambal'),
                 ('Menu B - Nasi Liwet Ikan Asin', 'Nasi liwet, ikan asin, tahu tempe, sambal')]:
        c.execute('INSERT INTO menu_food(name,description) VALUES(?,?)', (n, d))
    for n in ['Es Teh Manis', 'Air Mineral', 'Es Jeruk']:
        c.execute('INSERT INTO menu_drink(name) VALUES(?)', (n,))
    for n, i, s in [('Tumbler', '🥤', 2), ('Powerbank', '🔋', 2), ('Voucher', '🎟️', 2), ('Tote Bag', '👜', 2)]:
        c.execute('INSERT INTO rewards(name,icon,stock) VALUES(?,?,?)', (n, i, s))
    names = ['Peserta A', 'Peserta B', 'Peserta C', 'Peserta D', 'Peserta E', 'Peserta F', 'Peserta G', 'Peserta H']
    import datetime
    nowts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for i, n in enumerate(names, 1):
        code = 'DEMO%02d' % i
        cur = c.execute('INSERT INTO participants(code,name,division,created_at) VALUES(?,?,?,?)', (code, n, 'Demo', nowts))
        c.execute('INSERT INTO reward_assignments(participant_id,reward_id,claim_code) VALUES(?,?,?)',
                  (cur.lastrowid, (i - 1) % 4 + 1, 'RR-' + ''.join(secrets.choice(ALPHA) for _ in range(4))))
